const app = require("./app");
const dotenv = require("dotenv");
const mongoose = require("mongoose");
dotenv.config({path:"./config.env"});

mongoose.connect(process.env.MONGOCONNECTION)
.then(() => console.log("Database bağlantısı başarılı."))
.catch(err => console.error("MongoDb bağlantısı başarısız : ",err));

app.listen(process.env.PORT,()=> {
    console.log(`Sunucu ${process.env.PORT} portunda çalışıyor.`);
}); 