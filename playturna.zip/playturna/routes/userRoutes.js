const express = require("express");
const userController = require("../controllers/userController");
const authController = require("../controllers/authController");
const userRouter = express.Router();

userRouter.post("/signup", authController.signup);
userRouter.post("/login", authController.login);
userRouter
    .route("/")
    .get(authController.protect
        , authController.restrictTo("admin", "lead-moderator", "moderator")
        , userController.getUsers)
userRouter.post("/",
    authController.protect
    , authController.restrictTo("admin", "lead-moderator", "moderator"),
     userController.createUser);
userRouter.get("/:id", authController.protect
    ,authController.restrictTo("admin","lead-moderator","moderator"), userController.getUserById);
userRouter.put("/:id", authController.protect
    ,authController.restrictTo("admin","lead-moderator","moderator"), userController.updateUserById);
userRouter.delete("/:id",authController.protect
    ,authController.restrictTo("admin","lead-moderator","moderator") , userController.deleteUserById);

module.exports = userRouter; 