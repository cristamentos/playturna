const express = require("express");
const predictionController = require("../controllers/predictionController");
const authController = require("../controllers/authController");

const predictionRouter = express.Router();

predictionRouter
    .route("/")
    .get(predictionController.getPredictions)
    .post(authController.protect,authController.restrictTo("lead-moderator","admin"),predictionController.createPrediction)

module.exports = predictionRouter;