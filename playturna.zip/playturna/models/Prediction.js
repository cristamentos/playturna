const mongoose = require("mongoose");

const commentSchema = new mongoose.Schema({
    createdBy:{
        type:String,
        required:true
    },
    content:{
        type:String,
        required:true,
        minlength:[10,"Lütfen en az 10 karakter giriniz."],
        maxlength:[200,"Lütfen 200 karakterden daha az bir yorum yapın."]
    },
    createdAt:{
        type:Date,
        default:Date.now
    }
})

const predictionSchema = new mongoose.Schema({
    title:{
        type:String,
        required:[true,"Lütfen başlık giriniz."], // TODO tüm hepsine açıklama ekle
        unique:true
    },
    imageUrl:{
        type:String,
        required:true,
        default:"default-image.png"
    },
    createdBy:{
        type:String,
        required:true
    },
    description:{
        type:String,
        required:true
    },
    yesCount:{
        type:Number,
        default:0,
    },
    noCount:{
        type:Number,
        default:0
    },
    yesOdd:{
        type:Number,
        default:1.0
    },
    noOdd:{
        type:Number,
        default:1.0
    },
    endDate:{
        type:Date,
        required:true
    },
    category:{
        type:String,
        enum:["Gündem","Siyaset","Spor","Magazin"],
        default:"Gündem"
    },
    createdAt:{
        type:Date,
        default:Date.now,
    },
    comments:[commentSchema]



})

const Prediction = mongoose.model("Prediction",predictionSchema);
module.exports = Prediction;