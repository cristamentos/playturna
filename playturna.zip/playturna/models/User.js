const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const userSchema = new mongoose.Schema({
    username: {
        type:String,
        required:true,
        unique:true,
        lowercase:true,
        trim:true,
        minlength: [3, 'Kullanıcı adı en az 3 karakter olmalıdır'],
        maxlength: [20, 'Kullanıcı adı en fazla 20 karakter olabilir']

    },
    email:{
        type:String,
        required:true,
        unique:true,
        minlength: [3, 'Mail en az 3 karakter olmalıdır'],
        maxlength: [50, 'Mail en fazla 50 karakter olabilir']
    },
    password:{
        type:String,
        required:true,
        select:false,
        minlength:[8,"Şifre en az 8 karakter olmalıdır."],
        maxlength:[40,"Şifre en fazla 40 karakter olmalıdır."]
    },
    role: {
        type:String,
        enum:["user","moderator","lead-moderator","admin"],
        default:"user"
    }
},{timestamps:true});

userSchema.pre("save", async function (next) {
    if (!this.isModified("password")) return next();

    this.password = await bcrypt.hash(this.password,11);
    next(); 

});

userSchema.methods.correctPassword = async function(candidatePassword,userPassword) {
    return await bcrypt.compare(candidatePassword,userPassword);
}


const User = mongoose.model("User",userSchema);

module.exports = User;