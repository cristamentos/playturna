const express = require("express");
const mongoose = require("mongoose");
const mongodb = require("mongodb");
const userRoutes = require("./routes/userRoutes");
const predictionRoutes = require("./routes/predictionRoutes");

const app = express();
app.use(express.json());

app.use("/api/v1/users",userRoutes);
app.use("/api/v1/predictions",predictionRoutes);

app.all("*",(req,res,next) => {
   
    const error = new Error(`${req.originalUrl} adresi bulunamadı`);
    error.status = 404;
    next(error);
})

// Error Handling Middleware

const handleCastErrorDB = err => {
    const message = `Geçersiz ${err.path} : ${err.value}`;
    const error = new Error(message);
    error.status = 400;
    return error;
} 

const handleDuplicateKey = err => {
    let geciciKey;
    if(err.errorResponse.keyValue.username) {
        geciciKey = err.errorResponse.keyValue.username;
    } else if(err.errorResponse.keyValue.email) {
        geciciKey = err.errorResponse.keyValue.email;
    }
    const message = `${geciciKey} zaten kayıtlı.`;
    const error = new Error(message);
    error.status = 400;
    return error;
} 

app.use((err, req, res, next) => {
    
  
    console.log(err.message);
    if(err.name === "CastError") err = handleCastErrorDB(err);
    if(err.code === 11000) err = handleDuplicateKey(err);
    res.status(err.status || 500).json({
        status:"failure",
        message: err.message,
    });
});


module.exports = app;