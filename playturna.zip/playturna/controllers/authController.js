const { promisify } = require("util");
const User = require("./../models/User");
const jwt = require("jsonwebtoken");

const signToken = id => {
    return jwt.sign({ id: id }, process.env.SECRET_JWT, { expiresIn: process.env.EXPIRES_IN_JWT });
}

exports.signup = async (req, res, next) => {
    try {

   
    const newUser = await User.create({
        username: req.body.username,
        email: req.body.email,
        password: req.body.password,
        role:"user"
    });

    const token = signToken(newUser._id);

    res.status(200).json({
        status: "success",
        token,
        data: {
            user: newUser
        }
    })
} catch (err) {
   next(err);
}
}

exports.login = async (req, res) => {
    
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(404).json({
            status: "failure",
            message: "Email ya da şifre boş."
        })
    }

    const user = await User.findOne({ email }).select("+password");
    if (!user) {
        return res.status(401).json({
            status: "failure",
            message: "Kullanıcı adı ya da şifre yanlış"
        })
    }
    const isPasswordCorrect = await user.correctPassword(password, user.password);

    if (!isPasswordCorrect) {
        return res.status(401).json({
            status: "failure",
            message: "Kullanıcı adı ya da şifre yanlış"
        })
    }

    const token = signToken(user._id);

    res.status(200).json(
        {
            status: "success",
            token
        }
    )
}

exports.protect = async (req, res, next) => {
    let token;
    if (req.headers.authorization && req.headers.authorization.startsWith("Bearer")) {
        token = req.headers.authorization.split(" ")[1];
    }

    if (!token) {
        const error = new Error(`Giriş yapmadınız. Lütfen giriş yapınız.`);
        error.status = 401;
        return next(
            error
        )
    }
    let decoded;
    try {
         decoded = await promisify(jwt.verify)(token, process.env.SECRET_JWT);
    } catch (err) { 
        let errorMessage;
        if(err.expiredAt) {
             errorMessage = "Oturum süreniz doldu. Lütfen tekrar giriş yapınız.";
        } else {
            errorMessage = "Geçersiz token. Lütfen tekrar giriş yapınız."
        }
        const error = new Error(errorMessage);
        error.status = 401;
        return next(error) 
    }

    const userStillExists =  await User.findById(decoded.id);

    if(!userStillExists) {
        const error = new Error("Bu hesap silinmiş.");
        error.status = 401;
        return next(error)  
    }
    req.user = userStillExists;
    next();
}

exports.restrictTo = (...roles) => {
    return (req,res,next) => {
        // roles ["admin","lead-moderator","moderator"] || role="user"

        if(!roles.includes(req.user.role)) {
            const error = new Error("Bunu yapmak için yetkin yok.");
            error.status = 403;
            return next(error)
        }

        next();
    }
}