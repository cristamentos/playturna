const Prediction = require("../models/Prediction");

// Create Prediction
exports.createPrediction = async (req,res,next) => {
    try {
        const newPrediction = await Prediction.create({
            title:req.body.title,
            imageUrl:req.body.imageUrl,
            createdBy:req.body.createdBy,
            description:req.body.description,
            yesCount:req.body.yesCount,
            noCount:req.body.noCount,
            yesOdd:req.body.yesOdd,
            noOdd:req.body.noOdd,
            endDate:req.body.endDate,
            category:req.body.category
        });
        res.status(200).json({
            status:"success",
            data:newPrediction
        })
    } catch (err) {
        next(err);
    }
}


// get all predictions
exports.getPredictions = async (req,res,next) => {
    try {
        const predictions = await Prediction.find();
        res.status(200).json(predictions);
    } catch (err) {
        next(err);
    }
}
// Get Prediction by id
// Get prediction by category
// update prediction
// delete prediction